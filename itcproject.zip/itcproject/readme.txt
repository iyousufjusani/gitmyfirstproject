Tools Used:
 The tools used in this project are,
�	Dev C/C++.
�	C language.
 
Project Description:
�	First fall before running the program I have to informed that I worked in sub-cpp files so the main file to run the program is �FIRST PAGE�. Upon running this program, the compiler first asks the user to enter the mail project name (ourmail), after it ask the user to login or sign up, firstly for signup the computer shows a menu and asking your little personal information required as for signup requirement, name, username, password, date of birth, gender, city/country, phone number. If the user enters the format wrong or password not match it will say to enter again. After that when done with signup or if account is already existing then the user has to login. Then compiler returned to main menu and ask the user to enter option if user person choses login, then user is asked to enter the username if exists then user ask to enter password. If correct then account open, if not then it will ask user to enter the username and password whole again. After login, it will show three option compose, mails, logout. In compose option it will allow you to send mails for others. In mails option, you can see your received mails. In logout option, it will logout id and returned to main menu.
