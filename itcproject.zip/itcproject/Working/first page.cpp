#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ctime>
#include <time.h>
#include "signup.cpp"
#include "login.cpp"

//the function below is only to delay the output 
void delay(unsigned int mseconds){
    clock_t goal = mseconds + clock();
    while (goal > clock());
}

void main_page();
//void instructions();
void chk();
void found(char search[]);
void not_found(char search[]);



int main(){
	main_page();
	chk();
}
//void instructions(){
//	printf("Type 'x or X close' to close the window\n");
//	printf("Type 'b or B or backword' to back to Main menu\n");
//	printf("Type 'l or L or login' to login the menu");
//	printf("Type 's or S or signup' to sign up/to create ID");
//	printf("Type 'Logout ' to logout from ID");
//	
//}

void main_page(){
	system("cls");
//	fflush(stdin);
	system("color FC");//FC white red and 0C black red 
	printf("  Yooggle.com   \\ +\t\t\t\t\t\t\t\t\t\t\t\t   | X\n");
	printf("----------------------------------------------------------------------------------------------------------------------\n");
	printf("<-  ->  G | http://wwwyooggle.com\t\t\t\t\t\t\t\t\t\tT *|..\n");
	printf("----------------------------------------------------------------------------------------------------------------------\n");
	printf("\n\n\n\n\n\n\n");
	printf("\t\t\t\t\t\tY O O G G L E\n\t\t\t\t\t\t\t   Pakistan\n");
	printf("\t\t\t       ________________________________________________\n");
	printf("\t\t\t       |Search: ");
	fflush(stdin);
	
	
	//getch();
}

void chk(){
	//for multiple conditions
	char a[30]={"www.ourmail.com"};
	char b[30]={"www.ourmail.com "};
	char c[20]={"ourmail.com"};
	char d[20]={"ourmail.com "};
	char e[20]={"OURMAIL.COM"};
	char f[20]={"OURMAIL.COM "};
	char g[20]={"Ourmail.com"};
	char h[20]={"Ourmail.com "};
	char i[20]={"ourmail"};
	char j[20]={"ourmail "};
	char k[20]={"Ourmail"};
	char l[20]={"Ourmail "};
	char m[20]={"OURMAIL"};
	char n[20]={"OURMAIL "};
	char x[100];
	
	fflush(stdin);
	gets(x);

	printf("\t\t\t       |______________________________________________|\n");
	printf("\n\n\n\n\n\n");
	delay(1200);
	if(strcmp(x,a)==0 || strcmp(x,b)==0 || strcmp(x,c)==0 || strcmp(x,d)==0 || strcmp(x,e)==0 || strcmp(x,f)==0 || strcmp(x,g)==0)
	{
		found(x);
	}
	else if(strcmp(x,h)==0 || strcmp(x,i)==0 || strcmp(x,j)==0 || strcmp(x,k)==0 || strcmp(x,l)==0 || strcmp(x,m)==0 || strcmp(x,n)==0)
	{
		found(x);
	}
	else{
			not_found(x);
		}

}

void found(char search[]){
	system("cls");
	system("color FC");//FC white red and 0C black red 
	printf("  %s   \\ +\t\t\t\t\t\t\t\t\t\t\t\t   | X\n",search);
	printf("----------------------------------------------------------------------------------------------------------------------\n");
	printf("<-  ->  G | http://%s/login/sigup/u/continue\t\t\t\t\t\t\t\tT *|..\n",search);
	printf("----------------------------------------------------------------------------------------------------------------------\n");
	printf("\n\n\n\n\n");
	delay(100);
	printf("\t\t\t\t\t\t ' Welcome  To '\n\n");
	int i=0;
	char p[200]="\t\t\t\t\t\t  O U R M A I L\n";
	while (p[i]!='\0')
	{
		printf("%c",p[i]);
 	   delay(100);
		i++;
	}
	printf("\n\n\t\t\t\t\tDon't have an account? 'Sign up?'\n");
	printf("\t\t\t\t\t\t\t\t-------\n");
	printf("\t\t\t\t\t_________________________________\n");
	printf("\t\t\t\t\t|\t\t\t\t|\n");
	printf("\t\t\t\t\t|\tEnter\t  Cancel   \t|\n");
	printf("\t\t\t\t\t|\t-----\t  ------   \t|\n");
	printf("\t\t\t\t\t|\t\t\t\t|\n");
	printf("\t\t\t\t\t|  Login ID:    \t\t|\n");
	printf("\t\t\t\t\t|  Password:    \t\t|\n");
	printf("\t\t\t\t\t|\t\t\t\t|\n");
	printf("\t\t\t\t\t|_______________________________|\n\n");
	printf("\t\t\t\t\t\t  Login  (login)\n\t\t\t\t\t\t  Signup (signup)\n");
	printf("\t\t\t\t\t      Enter your choice: ");
	char option[50];
	gets(option);
	if(strcmp(option,"login")==0){
		login();
		delay(300);
		found(search);
	}
	else if(strcmp(option,"signup")==0){
		signup_account();
		printf("\t\t\t\tYou have successfully created your account");
		printf("\n\t\t\t\tReturning back to main menu (Press any key)");
		getch();
		delay(300);
		found(search);
	}
	else{
		found(search);
	}
}

void not_found(char search[]){
	system("cls");
	system("color FC");//FC white red and 0C black red 
	printf("  %s   \\ +\t\t\t\t\t\t\t\t\t\t\t\t   | X\n",search);
	printf("----------------------------------------------------------------------------------------------------------------------\n");
	printf("<-  ->  G | http://%s\t\t\t\t\t\t\t\t\t\t\tT *|..\n",search);
	printf("----------------------------------------------------------------------------------------------------------------------\n");
	printf("\n\n\n\n\n\n\n\n\n");
	delay(250);
	printf("\t\t\t(-_-)\n\n");
	printf("\t\t\tThis site can\'t be reached.\n\n");
	printf("\t\t\t%s\'s server DNS address could not be found.\n",search);
	printf("\t\t\tERR_NAME_NOT_RESOLVED");
	
	printf("\n\n\n\n\n\n");
	printf("\t\t\t\t\t\t\t\t\t\t\tTo go back to previos: (Press b)\n");
	printf("\t\t\t\t\t\t\t\t\t\t\tTo close the Window: (Press x)\n");
	printf("\t\t\t\t\t\t\t\t\t\t\tEnter your option: ");
	
	char option2;
	scanf("%c", &option2);
	switch(option2){
		case 'x':
		case 'X':
			exit(1);
			break;
			
			case 'b':
			case 'B':
				main();
				break;
				
				default:		
				not_found(search);	
				break;
		
	}
}




